<!DOCTYPE html>
<html>
    <head>
        <title>@yield('titulo')</title>
        <link rel="stylesheet" type="text/css" href="/css/app.css">
        <script type="text/javascript" src="/js/app.js"></script>
    </head>
    <body>
        <div class="container">
            @include('partials.nav')
            @yield('contenido')
        </div>
    </body>
</html>
