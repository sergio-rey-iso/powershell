<!DOCTYPE html>
<html>
    <head>
        <title><?php echo $__env->yieldContent('titulo'); ?></title>
        <link rel="stylesheet" type="text/css" href="/css/app.css">
        <script type="text/javascript" src="/js/app.js"></script>
    </head>
    <body>
        <div class="container">
            <?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('contenido'); ?>
        </div>
    </body>
</html>
<?php /**PATH /home/alumno/Proyectos/biblioteca/resources/views/plantilla.blade.php ENDPATH**/ ?>