<?php $__env->startSection('titulo', "Error 404"); ?>

<?php $__env->startSection('contenido'); ?>
    <h1>Error</h1>
    <p>Documento no encontrado</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumno/Proyectos/biblioteca/resources/views/errors/404.blade.php ENDPATH**/ ?>