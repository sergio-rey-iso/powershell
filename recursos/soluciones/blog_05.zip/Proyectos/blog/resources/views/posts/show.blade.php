@extends('plantilla')

@section('titulo', 'Ficha post')

@section('contenido')
    <h1>{{ $post->titulo }}</h1>
    <p><em>Escrito por {{ $post->usuario->login }}
        el {{ Carbon\Carbon::parse($post->created_at)->format("d/m/Y") }}</em></p>
    <div>
        {{ $post->contenido }}
    </div>

    <h3>Comentarios</h3>
    @forelse ($post->comentarios as $comentario)
        <div class="card">
            <div class="card-body">
                {{ $comentario->contenido }}
            </div>
            <div class="card-footer">
                <em>{{ $comentario->usuario->login }}</em>
            </div>
        </div>
    @empty
        <p>No hay comentarios en este post.</p>
    @endforelse
@endsection
