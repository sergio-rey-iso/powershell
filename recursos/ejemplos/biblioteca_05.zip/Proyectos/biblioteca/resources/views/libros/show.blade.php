@extends('plantilla')

@section('titulo', 'Ficha de libro')

@section('contenido')
    <h1>Ficha de libro {{ $libro->id }}</h1>
    <p>Título: {{ $libro->titulo }}</p>
    <p>Editorial: {{ $libro->editorial }}</p>
    <p>Precio: {{ $libro->precio }}</p>
@endsection
