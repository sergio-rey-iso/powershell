@extends('plantilla')

@section('titulo', 'Ficha de libro')

@section('contenido')
    <h1>Ficha de libro {{ $id }}</h1>
@endsection
