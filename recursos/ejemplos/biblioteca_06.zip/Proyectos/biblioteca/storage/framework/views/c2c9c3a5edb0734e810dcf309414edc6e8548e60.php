<?php $__env->startSection('titulo', 'Ficha de libro'); ?>

<?php $__env->startSection('contenido'); ?>
    <h1>Ficha de libro <?php echo e($libro->id); ?></h1>
    <p>Título: <?php echo e($libro->titulo); ?></p>
    <p>Editorial: <?php echo e($libro->editorial); ?></p>
    <p>Precio: <?php echo e($libro->precio); ?></p>
    <p>Autor: <?php echo e($libro->autor->nombre); ?> (<?php echo e($libro->autor->nacimiento); ?>)</p>

    <form action="<?php echo e(route('libros.destroy', $libro->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <input type="submit" class="btn btn-danger" value="Borrar libro" />
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumno/Proyectos/biblioteca/resources/views/libros/show.blade.php ENDPATH**/ ?>