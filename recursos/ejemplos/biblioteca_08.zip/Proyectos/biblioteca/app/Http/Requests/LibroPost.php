<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class LibroPost extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'titulo' => 'required|min:3',
            'editorial' => 'required',
            'precio' => 'required|numeric|min:0'
        ];
    }

    public function messages()
    {
        return [
            'titulo.required' => 'El título es obligatorio',
            'titulo.min' => 'El título es demasiado corto (al menos 3 caracteres)',
            'editorial.required' => 'La editorial es obligatoria',
            'precio.required' => 'El precio es obligatorio',
            'precio.numeric' => 'El precio debe ser un valor numérico',
            'precio.min' => 'El precio debe ser positivo'
        ];
    }
}
