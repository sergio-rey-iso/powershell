<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('inicio');
})->name('inicio');

// Rutas simples

/*
Route::get('posts', function () {
    return "Listado de posts";
})->name('posts_listado');

Route::get('posts/{id}', function ($id) {
    return "Ficha del post $id";
})->where('id', '[0-9]+')
->name('posts_ficha');
*/

// Rutas con vistas

Route::get('posts', function () {
    return view('posts.listado');
})->name('posts_listado');

Route::get('posts/{id}', function ($id) {
    return view('posts.ficha', compact('id'));
})->where('id', '[0-9]+')
->name('posts_ficha');
