@extends('plantilla')

@section('titulo', "Error 404")

@section('contenido')
    <h1>Error</h1>
    <p>Documento no encontrado</p>
@endsection
