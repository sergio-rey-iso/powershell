<?php $__env->startSection('titulo', 'Nuevo libro'); ?>

<?php $__env->startSection('contenido'); ?>

<h1>Nuevo libro</h1>

<form action="<?php echo e(route('libros.store')); ?>" method="POST">

    <?php echo csrf_field(); ?>

    <div class="form-group">
        <label for="titulo">Título:</label>
        <input type="text" class="form-control" name="titulo" id="titulo" value="<?php echo e(old('titulo')); ?>">
        <?php if($errors->has('titulo')): ?>
            <div class="text-danger">
                <?php echo e($errors->first('titulo')); ?>

            </div>
        <?php endif; ?>
    </div>

    <div class="form-group">
        <label for="editorial">Editorial:</label>
        <input type="text" class="form-control" name="editorial" id="editorial" value="<?php echo e(old('editorial')); ?>">
        <?php if($errors->has('editorial')): ?>
            <div class="text-danger">
                <?php echo e($errors->first('editorial')); ?>

            </div>
        <?php endif; ?>
    </div>

    <div class="form-group">
        <label for="precio">Precio:</label>
        <input type="text" class="form-control" name="precio" id="precio" value="<?php echo e(old('precio')); ?>">
        <?php if($errors->has('precio')): ?>
            <div class="text-danger">
                <?php echo e($errors->first('precio')); ?>

            </div>
        <?php endif; ?>
    </div>

    <div class="form-group">
        <label for="autor">Autor:</label>
        <select class="form-control" name="autor" id="autor">
            <?php $__currentLoopData = $autores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($autor->id); ?>">
                    <?php echo e($autor->nombre); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <input type="submit" name="enviar" value="Enviar" class="btn btn-dark btn-block">

</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumno/Proyectos/biblioteca/resources/views/libros/create.blade.php ENDPATH**/ ?>