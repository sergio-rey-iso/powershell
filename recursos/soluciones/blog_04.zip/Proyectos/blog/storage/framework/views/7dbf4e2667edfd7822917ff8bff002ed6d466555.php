<?php $__env->startSection('titulo', 'Inicio'); ?>

<?php $__env->startSection('contenido'); ?>
    <h1>Página de inicio</h1>
    Bienvenido/a al blog
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumno/Proyectos/blog/resources/views/inicio.blade.php ENDPATH**/ ?>